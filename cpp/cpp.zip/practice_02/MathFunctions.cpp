#include "MathFunctions.h"
#include <fstream>
#include <iostream>
#include <math.h>
#include <vector>


int MathFunctions::compute_factorial(int n)
{
    return n;
}


double MathFunctions::compute_dot_product(std::array<double, 3> vector_u, std::array<double, 3> vector_v)
{
    return vector_u[0];
}


std::array<double, 3> MathFunctions::compute_cross_product(std::array<double, 3> vector_u, std::array<double, 3> vector_v)
{
    return vector_u;
}
